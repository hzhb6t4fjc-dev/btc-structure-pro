# BTC Structure Pro v4

Professional static web app for BTC technical-structure monitoring.

Features:
- Live BTCUSDT market feed
- 15m / 1H / 4H / 1D analysis
- Multi-timeframe Long/Short conditional scanner
- Liquidity sweep and displacement heuristics
- Browser notification permission
- Alert history stored locally in the browser
- GitHub Pages ready

## Publish
Upload the contents of this folder to a GitHub repository and enable GitHub Pages.
GitHub Pages supports static HTML/CSS/JS sites. The app connects directly to public market-data endpoints from the browser.

## Important
This is an educational technical-analysis tool. Scores and alerts are rule-based signals, not probabilities, financial advice, or guarantees.
